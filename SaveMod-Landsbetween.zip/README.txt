This is a mod containing an exported world save from Core Keeper.

You can upload this zip to a mod at mod.io to share your world with others.

The format is very easy to understand if you want to add this to another mod or add more saves to the same mod. The files in the Saves subfolder should have the same structure as the saves folder in the game's data folder and the manifest file should be in the root of the zip file and contain all files included in the mod.
